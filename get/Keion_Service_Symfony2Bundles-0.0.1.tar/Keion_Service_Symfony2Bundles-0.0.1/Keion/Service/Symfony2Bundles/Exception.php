<?php

/**
 * @namespace
 */
namespace Keion;

/**
 * @category   Keion
 * @package    Service
 * @subpackage Symfony2Bundles
 */
interface Exception
{
}
