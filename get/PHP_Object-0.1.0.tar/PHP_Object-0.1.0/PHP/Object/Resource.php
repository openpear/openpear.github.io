<?php
require_once "PHP/Object.php";

class PHP_Object_Resource extends PHP_Object
{
    public $argOffsets =  array(
    );

}
