<?php
/**
 * jpSendMailException class
 *
 * @package    jpSimpleMailPlugin
 * @subpackage exception
 * @author     brt.river <brt.river@gmail.com>
 * @version    $Id: jpSendMailException.class.php 129 2008-11-29 17:03:40Z brtriver $
 */
class jpSendMailException extends sfException
{
}
