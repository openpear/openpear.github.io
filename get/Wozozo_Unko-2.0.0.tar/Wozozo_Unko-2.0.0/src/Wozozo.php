<?php
/** 
 * 
 * 
 */

class Wozozo
{
    function __construct()
    {
        print "wozozo is hello";
    }

    function __destruct()
    {
    	echo 'ヽ( ・∀・)ﾉ ｳﾝｺｰー！'
    }
}
