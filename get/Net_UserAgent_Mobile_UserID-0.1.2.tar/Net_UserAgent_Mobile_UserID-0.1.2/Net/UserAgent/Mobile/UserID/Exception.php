<?php


class Net_UserAgent_Mobile_UserID_Exception extends Exception
{
}
