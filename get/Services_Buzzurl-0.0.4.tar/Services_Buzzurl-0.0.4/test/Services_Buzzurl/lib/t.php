<?php
ini_set('include_path', realpath(dirname(__FILE__) . '/../../../'));
require_once dirname(__FILE__) . '/lime/lime.php';
