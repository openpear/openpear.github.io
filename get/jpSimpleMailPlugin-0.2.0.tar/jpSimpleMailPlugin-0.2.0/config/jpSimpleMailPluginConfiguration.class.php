<?php

/**
 * jpSimpleMailPlugin configuration.
 * 
 * @package     jpSimpleMailPlugin
 * @subpackage  config
 * @author      Your name here
 * @version     SVN: $Id: jpSimpleMailPluginConfiguration.class.php 128 2008-11-29 17:02:45Z brtriver $
 */
class jpSimpleMailPluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}
