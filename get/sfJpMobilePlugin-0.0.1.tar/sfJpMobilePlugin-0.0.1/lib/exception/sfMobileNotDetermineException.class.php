<?php
/* vim:set expandtab tabstop=2 softtabstop=2 shiftwidth=2: */
/**
 * sfMobileNotDetermineException
 *
 * @package     sfJpMobilePlugin
 * @subpackage  exception
 * @version     $Id$
 */
class sfMobileNotDetermineException extends sfException
{
}
