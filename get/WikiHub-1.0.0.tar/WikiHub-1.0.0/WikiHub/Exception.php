<?php
/** 
 * 
 * 
 */

class WikiHub_Exception extends Exception
{
}
