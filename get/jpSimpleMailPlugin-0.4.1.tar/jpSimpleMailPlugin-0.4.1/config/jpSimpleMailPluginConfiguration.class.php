<?php

/**
 * jpSimpleMailPlugin configuration.
 * 
 * @package     jpSimpleMailPlugin
 * @subpackage  config
 * @author      brt.river <brt.river@gmail.com>
 * @version     SVN: $Id: jpSimpleMailPluginConfiguration.class.php 2312 2011-01-06 09:02:47Z brtriver $
 */
class jpSimpleMailPluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}
