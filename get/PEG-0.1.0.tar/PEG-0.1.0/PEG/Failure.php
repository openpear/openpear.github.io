<?php

class PEG_Failure extends Exception
{

}