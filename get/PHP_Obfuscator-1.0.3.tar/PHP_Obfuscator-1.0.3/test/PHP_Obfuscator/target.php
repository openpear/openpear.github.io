hogehoge
<?php
echo date('Y/m/d H:i:s') . PHP_EOL;
