<?php
require_once('HTTP/Request2/Exception.php');

class HTTP_OAuthConsumer_Exception extends HTTP_Request2_Exception
{
}
