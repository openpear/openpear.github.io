<?php
/**
 * @package HatenaSyntax
 * @author anatoo<anatoo@nequal.jp>
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 * @version $Id: NodeCreater.php 658 2009-04-12 07:47:13Z anatoo $
 */

class HatenaSyntax_NodeCreater implements PEG_IParser
{
    protected $keys, $parser;
    function __construct($type, PEG_IParser $parser, Array $keys = array())
    {
        $this->type = $type;
        $this->keys = $keys;
        $this->parser = $parser;
    }
    function parse(PEG_IContext $context)
    {
        $result = $this->parser->parse($context);
        if ($result instanceof PEG_Failure) return $result;
        
        $data = array();
        if (count($this->keys) > 0) foreach ($this->keys as $i => $key) {
            $data[$key] = $result[$i];
        }
        else {
            $data = $result;
        }
        
        return new HatenaSyntax_Node($this->type, $data);
    }
}