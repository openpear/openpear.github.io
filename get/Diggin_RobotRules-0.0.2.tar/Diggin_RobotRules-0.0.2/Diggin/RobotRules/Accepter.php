<?php

namespace Diggin\RobotRules;

interface Accepter
{}
