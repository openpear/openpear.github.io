<?php

namespace Diggin\RobotRules;

interface Exception
{}
