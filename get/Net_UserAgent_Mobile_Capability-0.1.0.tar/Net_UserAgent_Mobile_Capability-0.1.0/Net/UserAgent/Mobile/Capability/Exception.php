<?php

require_once 'PEAR/Exception.php';


class Net_UserAgent_Mobile_Capability_Exception extends PEAR_Exception
{
}
