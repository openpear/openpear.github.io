<?php
/** 
 * 
 * 
 */

class Wozozo
{
    function __construct()
    {
        print "wozozo is hello";
    }
}
