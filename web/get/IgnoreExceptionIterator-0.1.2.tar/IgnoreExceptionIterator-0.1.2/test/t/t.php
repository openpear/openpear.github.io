<?php
include_once dirname(__FILE__) . '/lime.php';
include_once dirname(__FILE__) . '/../../src/IgnoreExceptionIterator.php';
