<?php

interface Diggin_Http_Response_Charset_Encoder_EncoderInterface
{
    public function encode($resouce, $remains = null);
}
