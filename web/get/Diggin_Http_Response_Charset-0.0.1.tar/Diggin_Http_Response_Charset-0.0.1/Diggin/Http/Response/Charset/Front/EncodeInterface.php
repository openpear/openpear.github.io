<?php

interface Diggin_Http_Response_Charset_Front_EncodeInterface
{
    public function encode($resouce, $remains = null);
}

