<?php
include_once dirname(__FILE__) . '/MessagePackRPC/Future.php';
include_once dirname(__FILE__) . '/MessagePackRPC/Client.php';
include_once dirname(__FILE__) . '/MessagePackRPC/Server.php';
include_once dirname(__FILE__) . '/MessagePackRPC/Back.php';