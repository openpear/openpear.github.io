<?php

/**
 * jpSimpleMailPlugin configuration.
 * 
 * @package     jpSimpleMailPlugin
 * @subpackage  config
 * @author      brt.river <brt.river@gmail.com>
 * @version     SVN: $Id: jpSimpleMailPluginConfiguration.class.php 2317 2011-01-08 15:56:25Z ganchiku $
 */
class jpSimpleMailPluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
    if (sfConfig::get('app_jpSimpleMail_swift_debug', false)) {
      $this->dispatcher->connect('debug.web.load_panels', array(
        'JpSwiftWebDebugPanelMailer', 'listenToLoadDebugWebPanelEvent'
      ));
    }
  }
}
