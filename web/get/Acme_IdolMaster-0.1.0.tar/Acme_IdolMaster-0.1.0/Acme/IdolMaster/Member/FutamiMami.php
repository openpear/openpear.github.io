<?php
/**
 * Acme_IdolMaster_Member_FutamiMami
 *
 * @author  yohei.kawano@gmail.com
 * @package openpear
 * @version $Id: FutamiMami.php 64 2008-11-07 03:33:32Z brick $
 */
require_once 'Acme/IdolMaster/Member/Base.php';

class Acme_IdolMaster_Member_FutamiMami
{
    private $first_name_ja = '真美';
    private $family_name_ja = '双海';
    private $first_name_en = 'Mami';
    private $family_name_en = 'Futami';
    private $nick = array('とかち');
    private $birthday = '05-22';
    private $blood_type = 'B';
    private $age = 12;
    private $character_voice = '下田麻美';
}
