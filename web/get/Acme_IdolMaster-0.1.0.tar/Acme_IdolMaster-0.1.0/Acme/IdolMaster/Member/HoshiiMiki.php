<?php
/**
 * Acme_IdolMaster_Member_HoshiiMiki
 *
 * @author  yohei.kawano@gmail.com
 * @package openpear
 * @version $Id: HoshiiMiki.php 64 2008-11-07 03:33:32Z brick $
 */
require_once 'Acme/IdolMaster/Member/Base.php';

class Acme_IdolMaster_Member_HoshiiMiki
{
    private $first_name_ja = '美希';
    private $family_name_ja = '星井';
    private $first_name_en = 'Miki';
    private $family_name_en = 'Hoshii';
    private $nick = array('ゆとり');
    private $birthday = '11-23';
    private $blood_type = 'B';
    private $age = 14;
    private $character_voice = '長谷川明子';
}
