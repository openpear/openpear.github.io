<?php
/**
 * Acme_IdolMaster_Member_KikuchiMakoto
 *
 * @author  yohei.kawano@gmail.com
 * @package openpear
 * @version $Id: KikuchiMakoto.php 64 2008-11-07 03:33:32Z brick $
 */
require_once 'Acme/IdolMaster/Member/Base.php';

class Acme_IdolMaster_Member_KikuchiMakoto
{
    private $first_name_ja = '真';
    private $family_name_ja = '菊地';
    private $first_name_en = 'Makoto';
    private $family_name_en = 'Kikuchi';
    private $nick = array('真');
    private $birthday = '08-29';
    private $blood_type = 'O';
    private $age = 16;
    private $character_voice = '平田宏美';
}
