<?php
/**
 * Acme_IdolMaster_Member_HagiwaraYukiho
 *
 * @author  yohei.kawano@gmail.com
 * @package openpear
 * @version $Id: HagiwaraYukiho.php 64 2008-11-07 03:33:32Z brick $
 */
require_once 'Acme/IdolMaster/Member/Base.php';

class Acme_IdolMaster_Member_HagiwaraYukiho
{
    private $first_name_ja = '雪歩';
    private $family_name_ja = '萩原';
    private $first_name_en = 'Yukiho';
    private $family_name_en = 'Hagiwara';
    private $nick = array('ゆきほ', 'ゆきぽ');
    private $birthday = '12-24';
    private $blood_type = 'A';
    private $age = 16;
    private $character_voice = '落合祐里香';
}
