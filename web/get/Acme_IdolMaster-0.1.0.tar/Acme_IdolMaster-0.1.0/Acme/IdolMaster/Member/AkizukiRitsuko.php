<?php
/**
 * Acme_IdolMaster_Member_AkizukiRitsuko
 *
 * @author  yohei.kawano@gmail.com
 * @package openpear
 * @version $Id: AkizukiRitsuko.php 64 2008-11-07 03:33:32Z brick $
 */
require_once 'Acme/IdolMaster/Member/Base.php';

class Acme_IdolMaster_Member_AkizukiRitsuko
{
    private $first_name_ja = '律子';
    private $family_name_ja = '秋月';
    private $first_name_en = 'Ritsuko';
    private $family_name_en = 'Akizuki';
    private $nick = array('りつこ', 'ローソン', '眼鏡');
    private $birthday = '06-23';
    private $blood_type = 'A';
    private $age = 18;
    private $character_voice = '若林直美';
}
