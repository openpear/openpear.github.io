<?php
interface PHP_Obfuscator_Encoder_Encoder
{
    public function encode();
    public function decode();
}
