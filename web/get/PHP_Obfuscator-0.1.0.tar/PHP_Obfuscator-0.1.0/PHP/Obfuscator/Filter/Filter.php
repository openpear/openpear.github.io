<?php
interface PHP_Obfuscator_Filter_Filter
{
    public function getCode();
}
