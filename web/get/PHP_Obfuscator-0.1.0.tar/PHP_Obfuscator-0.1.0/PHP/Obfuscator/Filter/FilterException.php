<?php
class PHP_Obfuscator_Filter_FilterException extends Exception
{
}
