<?php

class ClassOfPhobClassDescription extends ClassOfPhobBehavior
{
}

