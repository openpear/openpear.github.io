<?php

class ClassOfPhobObject extends PhobClass
{
}

