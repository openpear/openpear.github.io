<?php
interface Net_MobileCIDR_Interface{
  public function getIPAddresses();
}
