<?php

class ClassOfPhobBehavior extends ClassOfPhobObject
{

}

