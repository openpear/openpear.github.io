<?php

class ClassOfPhobClass extends ClassOfPhobClassDescription
{
}

