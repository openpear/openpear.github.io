<?php

$dir = dirname(__FILE__) . '/Phoblinks/';
require_once  $dir . 'PhobObject.php';
require_once  $dir . 'PhobBehavior.php';
require_once  $dir . 'PhobClassDescription.php';
require_once  $dir . 'PhobClass.php';
require_once  $dir . 'PhobMetaclass.php';
require_once  $dir . 'ClassOfPhobObject.php';
require_once  $dir . 'ClassOfPhobBehavior.php';
require_once  $dir . 'ClassOfPhobClassDescription.php';
require_once  $dir . 'ClassOfPhobClass.php';
require_once  $dir . 'ClassOfPhobMetaclass.php';
require_once  $dir . 'Phoblinks.php';
require_once  $dir . 'PhobInitializer.php';

require_once  $dir . 'PhobProperty.php';
require_once  $dir . 'PhobKeyValueCoding.php';
require_once  $dir . 'PhobValidation.php';
require_once  $dir . 'PhobClassBuilder.php';
require_once  $dir . 'PhobTrait.php';
require_once  $dir . 'PhobValueTransformer.php';
require_once  $dir . 'PhobValueValidator.php';

