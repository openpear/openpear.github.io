<?php echo 'さっぽろ' ?>
