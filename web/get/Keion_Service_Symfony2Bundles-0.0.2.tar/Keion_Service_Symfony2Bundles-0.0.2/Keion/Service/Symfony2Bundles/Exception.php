<?php

/**
 * @namespace
 */
namespace Keion\Service\Symfony2Bundles;

/**
 * @category   Keion
 * @package    Service
 * @subpackage Symfony2Bundles
 */
interface Exception
{
}
