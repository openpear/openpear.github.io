CREATE TABLE bench(
  name VARCHAR(255) primary key,
  value VARCHAR(255)
);
