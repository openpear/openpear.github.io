class Maple4_DocTest_%sTest extends PHPUnit_Framework_TestCase
{
%s
}
