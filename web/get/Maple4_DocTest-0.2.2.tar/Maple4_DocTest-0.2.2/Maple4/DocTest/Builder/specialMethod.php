private $obj;

public function setUp()
{
    $this->obj = new #class;
}

public function tearDown()
{
    $this->obj = null;
}
