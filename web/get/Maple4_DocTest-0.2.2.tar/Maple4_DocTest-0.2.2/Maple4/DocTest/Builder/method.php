    public function %s()
    {
%s
    }
