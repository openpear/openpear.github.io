<?php
require_once('%s');

%s
