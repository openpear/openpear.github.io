<?php

interface NorfComparator
{
    function compare($a, $b);
}



