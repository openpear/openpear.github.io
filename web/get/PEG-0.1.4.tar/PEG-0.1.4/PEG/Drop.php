<?php

class PEG_Drop extends PEG_Action
{
    function process($v)
    {
        return null;
    }
}
