<?php
namespace Diggin\RobotRules\Rules;

interface Txt extends \Iterator
{}
