<?php

class FreepagePeer extends BaseFreepagePeer
{
}
