<?php

class Freepage extends BaseFreepage
{
}
