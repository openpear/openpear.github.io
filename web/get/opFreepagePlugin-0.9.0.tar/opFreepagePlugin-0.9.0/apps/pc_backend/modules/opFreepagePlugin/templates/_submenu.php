<li><strong><?php echo __('フリーページ') . __('プラグイン') ?></strong></li>
<li><?php echo link_to(__('一覧'), 'opFreepagePlugin/list') ?></li>
<li><?php echo link_to(__('新規追加'), 'opFreepagePlugin/new') ?></li>
