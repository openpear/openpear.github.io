<?php
require_once 'PHP/Object/Numeric.php';

class PHP_Object_Numeric_Float extends PHP_Object_Numeric
{
}
