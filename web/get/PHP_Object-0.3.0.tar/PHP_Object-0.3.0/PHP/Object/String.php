<?php
require_once "PHP/Object.php";

class PHP_Object_String extends PHP_Object
{
}
