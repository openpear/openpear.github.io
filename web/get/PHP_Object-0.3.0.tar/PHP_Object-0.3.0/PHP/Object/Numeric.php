<?php
require_once 'PHP/Object.php';

class PHP_Object_Numeric extends PHP_Object
{

}
